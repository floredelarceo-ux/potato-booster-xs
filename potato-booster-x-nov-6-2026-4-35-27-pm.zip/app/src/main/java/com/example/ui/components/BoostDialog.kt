package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.StepStatus
import com.example.ui.theme.ChakraPetchFontFamily
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.FieryOrange
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TextGrayMuted
import com.example.ui.theme.TextGraySecondary
import com.example.ui.theme.TextWhitePrimary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun BoostDialog(
    viewModel: MainViewModel
) {
    val isBoosting by viewModel.isBoosting.collectAsState()
    val steps by viewModel.boostSteps.collectAsState()
    val report by viewModel.boostReport.collectAsState()
    val stats by viewModel.systemStats.collectAsState()

    if (!isBoosting && report == null) return

    val infiniteTransition = rememberInfiniteTransition(label = "boost_spin")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin_angle"
    )

    Dialog(
        onDismissRequest = {
            if (!isBoosting) viewModel.dismissBoostReport()
        },
        properties = DialogProperties(
            dismissOnBackPress = !isBoosting,
            dismissOnClickOutside = !isBoosting,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .clip(RoundedCornerShape(20.dp))
                .border(
                    width = 2.dp,
                    brush = Brush.verticalGradient(
                        colors = listOf(NeonCyan, NeonPurple, FieryOrange)
                    ),
                    shape = RoundedCornerShape(20.dp)
                )
                .background(CyberSurface)
                .padding(20.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                if (isBoosting) {
                    Box(
                        modifier = Modifier.size(54.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(54.dp),
                            color = NeonCyan,
                            strokeWidth = 3.dp
                        )
                        Icon(
                            imageVector = Icons.Default.RocketLaunch,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Text(
                        text = "ACCELERATING POTATO DEVICE...",
                        fontFamily = RajdhaniFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        letterSpacing = 1.sp,
                        color = TextWhitePrimary,
                        textAlign = TextAlign.Center
                    )

                    val completedCount = steps.count { it.status == StepStatus.COMPLETED || it.status == StepStatus.SKIPPED_NO_SHIZUKU }
                    val progress = if (steps.isNotEmpty()) completedCount.toFloat() / steps.size else 0f

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = NeonCyan,
                        trackColor = CyberSurfaceVariant
                    )
                } else if (report != null) {
                    val currentReport = report!!
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(NeonGreen.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = NeonGreen,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Text(
                        text = "POTATO BOOST COMPLETE",
                        fontFamily = RajdhaniFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        letterSpacing = 1.sp,
                        color = NeonGreen,
                        textAlign = TextAlign.Center
                    )

                    // Performance Report Highlight Card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CyberSurfaceVariant)
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "+${currentReport.ramFreedMb} MB",
                                    fontFamily = RajdhaniFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp,
                                    color = NeonCyan
                                )
                                Text(
                                    text = "RAM Reclaimed",
                                    fontFamily = ChakraPetchFontFamily,
                                    fontSize = 11.sp,
                                    color = TextGraySecondary
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${currentReport.processesTrimmed}",
                                    fontFamily = RajdhaniFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp,
                                    color = NeonGreen
                                )
                                Text(
                                    text = "Apps Trimmed",
                                    fontFamily = ChakraPetchFontFamily,
                                    fontSize = 11.sp,
                                    color = TextGraySecondary
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${currentReport.stepsCompleted}/${steps.size}",
                                    fontFamily = RajdhaniFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp,
                                    color = NeonPurple
                                )
                                Text(
                                    text = "Tweaks Applied",
                                    fontFamily = ChakraPetchFontFamily,
                                    fontSize = 11.sp,
                                    color = TextGraySecondary
                                )
                            }
                        }
                    }
                }

                // Step by Step Execution Logs (Scrollable)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberBackground)
                        .padding(10.dp)
                ) {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(steps.size) { i ->
                            val step = steps[i]
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                when (step.status) {
                                    StepStatus.COMPLETED -> Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = NeonGreen,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    StepStatus.RUNNING -> CircularProgressIndicator(
                                        modifier = Modifier.size(14.dp),
                                        strokeWidth = 2.dp,
                                        color = NeonCyan
                                    )
                                    StepStatus.SKIPPED_NO_SHIZUKU -> Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = FieryOrange,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    StepStatus.WARNING -> Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = FieryOrange,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    StepStatus.PENDING -> Icon(
                                        imageVector = Icons.Default.HourglassTop,
                                        contentDescription = null,
                                        tint = TextGrayMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = step.title,
                                        fontFamily = RajdhaniFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = when (step.status) {
                                            StepStatus.RUNNING -> NeonCyan
                                            StepStatus.COMPLETED -> TextWhitePrimary
                                            StepStatus.SKIPPED_NO_SHIZUKU -> FieryOrange
                                            else -> TextGrayMuted
                                        }
                                    )
                                    if (step.detail.isNotEmpty()) {
                                        Text(
                                            text = step.detail,
                                            fontFamily = ChakraPetchFontFamily,
                                            fontSize = 10.sp,
                                            color = TextGraySecondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Completion Action Buttons
                if (report != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.dismissBoostReport()
                                viewModel.launchMLBB()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeonGreen,
                                contentColor = CyberBackground
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("report_launch_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "LAUNCH MLBB",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        OutlinedButton(
                            onClick = { viewModel.dismissBoostReport() },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("report_done_btn")
                        ) {
                            Text(
                                text = "DONE",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = TextWhitePrimary
                            )
                        }
                    }
                }
            }
        }
    }
}
