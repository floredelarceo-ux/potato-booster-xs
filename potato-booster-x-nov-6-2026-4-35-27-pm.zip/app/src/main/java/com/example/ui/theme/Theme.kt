package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = CyberBackground,
    primaryContainer = CyberSurfaceVariant,
    onPrimaryContainer = NeonCyan,
    secondary = NeonPurple,
    onSecondary = Color.White,
    secondaryContainer = CyberSurfaceVariant,
    onSecondaryContainer = NeonPurpleBright,
    tertiary = NeonGreen,
    onTertiary = CyberBackground,
    background = CyberBackground,
    onBackground = TextWhitePrimary,
    surface = CyberSurface,
    onSurface = TextWhitePrimary,
    surfaceVariant = CyberSurfaceVariant,
    onSurfaceVariant = TextGraySecondary,
    outline = CyberCardBorder,
    outlineVariant = CyberCardBorderGlow
)

@Composable
fun PotatoBoosterTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
