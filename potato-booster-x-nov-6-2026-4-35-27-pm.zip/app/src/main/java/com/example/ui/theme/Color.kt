package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Obsidian / Gaming Night Backgrounds
val CyberBackground = Color(0xFF070A10)
val CyberSurface = Color(0xFF0F1523)
val CyberSurfaceVariant = Color(0xFF162035)
val CyberCardBorder = Color(0xFF1E2D4A)
val CyberCardBorderGlow = Color(0xFF00F0FF)

// Neon & Accent Colors
val NeonCyan = Color(0xFF00F0FF)
val NeonCyanDim = Color(0xFF00A8B3)
val NeonPurple = Color(0xFF9D4EDD)
val NeonPurpleBright = Color(0xFFB565FF)
val NeonGreen = Color(0xFF00FF9D)
val NeonGreenDim = Color(0xFF00B36E)
val FieryOrange = Color(0xFFFF6B00)
val FieryRed = Color(0xFFFF2A4B)
val GoldenYellow = Color(0xFFFFC700)

// Text & Monospace HUD Colors
val TextWhitePrimary = Color(0xFFF1F5F9)
val TextGraySecondary = Color(0xFF94A3B8)
val TextGrayMuted = Color(0xFF64748B)

// Glassmorphic Overlays
val GlassOverlayLight = Color(0x1400F0FF)
val GlassOverlayPurple = Color(0x149D4EDD)
val GlassOverlayDark = Color(0x990F1523)
