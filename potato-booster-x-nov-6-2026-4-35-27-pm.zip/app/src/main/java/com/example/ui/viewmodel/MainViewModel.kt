package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.BoostReport
import com.example.data.model.BoostStep
import com.example.data.model.MLBBGraphicPreset
import com.example.data.model.MapThemePreset
import com.example.data.model.ModuleCategory
import com.example.data.model.OptimizationModule
import com.example.data.model.PerformanceProfile
import com.example.data.model.ProfileType
import com.example.data.model.ShizukuState
import com.example.data.model.SystemStats
import com.example.data.repository.AppSettings
import com.example.data.repository.BoosterEngine
import com.example.data.repository.MLBBRepository
import com.example.data.repository.ModuleRepository
import com.example.data.repository.SettingsRepository
import com.example.data.repository.SystemMonitorRepository
import com.example.service.ShizukuManager
import com.example.ui.theme.FieryOrange
import com.example.ui.theme.FieryRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    SPLASH,
    HOME,
    MLBB,
    PERFORMANCE,
    MODULES,
    SETTINGS
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext

    val systemRepo = SystemMonitorRepository(context)
    val moduleRepo = ModuleRepository(context)
    val mlbbRepo = MLBBRepository()
    val settingsRepo = SettingsRepository(context)
    val boosterEngine = BoosterEngine(context, systemRepo)

    val systemStats: StateFlow<SystemStats> = systemRepo.systemStats
    val shizukuState: StateFlow<ShizukuState> = ShizukuManager.state
    val modules: StateFlow<List<OptimizationModule>> = moduleRepo.modules
    val backupStatus: StateFlow<String> = moduleRepo.backupStatus
    val settings: StateFlow<AppSettings> = settingsRepo.settings

    val isBoosting: StateFlow<Boolean> = boosterEngine.isBoosting
    val boostSteps: StateFlow<List<BoostStep>> = boosterEngine.steps
    val boostReport: StateFlow<BoostReport?> = boosterEngine.boostReport

    private val _currentScreen = MutableStateFlow(AppScreen.SPLASH)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _selectedModuleCategory = MutableStateFlow<ModuleCategory?>(null)
    val selectedModuleCategory: StateFlow<ModuleCategory?> = _selectedModuleCategory.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    val performanceProfiles = listOf(
        PerformanceProfile(
            id = ProfileType.POTATO,
            title = "Potato Overdrive",
            badge = "RECOMMENDED FOR 2-3GB",
            description = "Aggressive memory release, strict 60fps pacing, minimal thermal build-up.",
            targetFps = 60,
            accentColor = NeonCyan,
            ramAggressiveness = "Maximum (Zero background cache)",
            cpuScheduling = "Touch-bias clock burst",
            thermalLimitCelsius = 40,
            dexOptPriority = true
        ),
        PerformanceProfile(
            id = ProfileType.BALANCED,
            title = "Balanced Competitive",
            badge = "SMOOTH 60 FPS",
            description = "Ideal harmony of battery life, steady frame rate, and cool temperatures.",
            targetFps = 60,
            accentColor = NeonGreen,
            ramAggressiveness = "Standard dynamic LMK",
            cpuScheduling = "Balanced energy aware",
            thermalLimitCelsius = 42,
            dexOptPriority = false
        ),
        PerformanceProfile(
            id = ProfileType.PERFORMANCE,
            title = "Ultra Speed 90Hz",
            badge = "HIGH REFRESH",
            description = "Unlocks high refresh rate targets, accelerates touch sampling response.",
            targetFps = 90,
            accentColor = FieryOrange,
            ramAggressiveness = "High memory priority",
            cpuScheduling = "Performance governor",
            thermalLimitCelsius = 44,
            dexOptPriority = true
        ),
        PerformanceProfile(
            id = ProfileType.EXTREME,
            title = "Extreme Beast 120Hz",
            badge = "UNCONSTRAINED",
            description = "Pushes maximum hardware limits, forces GPU composition & max display Hz.",
            targetFps = 120,
            accentColor = FieryRed,
            ramAggressiveness = "Unconstrained heap",
            cpuScheduling = "High performance cores",
            thermalLimitCelsius = 46,
            dexOptPriority = true
        )
    )

    init {
        try {
            ShizukuManager.init(context)
        } catch (_: Throwable) {}
        try {
            systemRepo.startMonitoring(viewModelScope)
        } catch (_: Throwable) {}

        // Splash screen timer
        viewModelScope.launch {
            try {
                delay(1800)
                if (_currentScreen.value == AppScreen.SPLASH) {
                    _currentScreen.value = AppScreen.HOME
                }
            } catch (_: Throwable) {}
        }
    }

    override fun onCleared() {
        super.onCleared()
        systemRepo.stopMonitoring()
        ShizukuManager.destroy()
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun requestShizukuPermission() {
        if (!shizukuState.value.isInstalled) {
            showToast("Shizuku app is not installed. Please install Shizuku.")
            openShizukuDownload()
            return
        }
        if (!shizukuState.value.isRunning) {
            showToast("Shizuku is not running. Please start Shizuku service.")
            openShizukuApp()
            return
        }
        val success = ShizukuManager.requestPermission()
        if (!success) {
            showToast("Could not request Shizuku permission. Check Shizuku status.")
        }
    }

    fun triggerOneTapBoost() {
        viewModelScope.launch {
            boosterEngine.executeBoost(settings.value.selectedProfile)
        }
    }

    fun dismissBoostReport() {
        boosterEngine.dismissBoost()
    }

    fun launchMLBB() {
        val launched = systemRepo.launchMlbb()
        if (!launched) {
            showToast("Mobile Legends is not installed on this device.")
        }
    }

    fun selectModuleCategory(category: ModuleCategory?) {
        _selectedModuleCategory.value = category
    }

    fun toggleModule(id: String) {
        moduleRepo.toggleModule(id)
    }

    fun installModule(id: String) {
        moduleRepo.installModule(id)
        showToast("Module installed successfully")
    }

    fun uninstallModule(id: String) {
        moduleRepo.uninstallModule(id)
        showToast("Module uninstalled")
    }

    fun createBackup() {
        val name = moduleRepo.createBackup()
        showToast("Configuration saved: $name")
    }

    fun restoreDefaults() {
        moduleRepo.restoreDefaults()
        settingsRepo.resetToDefaults()
        showToast("Restored default configurations")
    }

    fun setRefreshRate(targetRate: Float) {
        val supported = systemStats.value.supportedRefreshRates
        if (!supported.contains(targetRate)) {
            showToast("Hardware limitation: $targetRate Hz is not physically supported by this screen.")
            return
        }

        settingsRepo.updateRefreshRate(targetRate)

        if (shizukuState.value.canExecuteElevated) {
            viewModelScope.launch {
                val res = ShizukuManager.executeElevatedCommand(
                    "settings put system peak_refresh_rate $targetRate && settings put system min_refresh_rate $targetRate"
                )
                if (res.isSuccess) {
                    showToast("Refresh rate set to ${targetRate.toInt()}Hz via Shizuku")
                } else {
                    showToast("Failed to write system setting: ${res.exceptionOrNull()?.message}")
                }
                systemRepo.updateHardwareStats()
            }
        } else {
            showToast("Saved preference: ${targetRate.toInt()}Hz. (Elevated write requires Shizuku)")
        }
    }

    fun openDisplaySettings() {
        try {
            val intent = Intent(Settings.ACTION_DISPLAY_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (_: Exception) {
            showToast("Could not open system display settings.")
        }
    }

    fun openShizukuApp() {
        try {
            val intent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            } else {
                openShizukuDownload()
            }
        } catch (_: Exception) {
            openShizukuDownload()
        }
    }

    private fun openShizukuDownload() {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (_: Exception) {}
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }
}
