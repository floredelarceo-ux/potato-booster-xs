package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MLBBGraphicPreset
import com.example.data.model.MapThemePreset
import com.example.ui.components.CyberCard
import com.example.ui.components.NeonButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.ChakraPetchFontFamily
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.FieryOrange
import com.example.ui.theme.FieryRed
import com.example.ui.theme.GoldenYellow
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TextGrayMuted
import com.example.ui.theme.TextGraySecondary
import com.example.ui.theme.TextWhitePrimary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun MLBBPotatoScreen(
    viewModel: MainViewModel
) {
    val stats by viewModel.systemStats.collectAsState()
    val presets = viewModel.mlbbRepo.graphicPresets
    val mapThemes = viewModel.mlbbRepo.mapPresets
    val settings by viewModel.settings.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var selectedPresetId by remember { mutableStateOf("preset_potato") }
    var selectedMapId by remember { mutableStateOf(settings.selectedMapThemeId) }
    var previewSplitRatio by remember { mutableFloatStateOf(0.5f) }

    val activePreset = presets.firstOrNull { it.id == selectedPresetId } ?: presets.first()
    val activeMap = mapThemes.firstOrNull { it.id == selectedMapId } ?: mapThemes.first()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // MLBB Quick Status Banner
            CyberCard(
                borderColor = NeonCyan.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "MLBB POTATO OPTIMIZER",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = TextWhitePrimary
                            )
                            StatusBadge(
                                text = if (stats.isMlbbInstalled) "INSTALLED" else "UNINSTALLED",
                                accentColor = if (stats.isMlbbInstalled) NeonGreen else FieryOrange,
                                isPulsing = false
                            )
                        }
                        Text(
                            text = "Safe performance profiles & display enhancements for low-end hardware",
                            fontFamily = ChakraPetchFontFamily,
                            fontSize = 12.sp,
                            color = TextGraySecondary
                        )
                    }

                    if (stats.isMlbbInstalled) {
                        Button(
                            onClick = { viewModel.launchMLBB() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeonGreen,
                                contentColor = CyberBackground
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("mlbb_launch_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "START",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        // Section Tabs: Presets vs Map Customization vs Guide
        item {
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = CyberSurface,
                contentColor = NeonCyan,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = NeonCyan
                    )
                },
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = {
                        Text(
                            text = "GRAPHICS PRESETS",
                            fontFamily = RajdhaniFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = {
                        Text(
                            text = "MAP & VISUALS",
                            fontFamily = RajdhaniFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                )
                Tab(
                    selected = selectedTabIndex == 2,
                    onClick = { selectedTabIndex = 2 },
                    text = {
                        Text(
                            text = "SETTINGS GUIDE",
                            fontFamily = RajdhaniFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                )
            }
        }

        when (selectedTabIndex) {
            0 -> {
                // Tab 0: Graphics Presets
                item {
                    Text(
                        text = "SELECT TARGET DEVICE PROFILE",
                        fontFamily = RajdhaniFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        letterSpacing = 1.sp,
                        color = NeonCyan
                    )
                }

                items(presets.size) { index ->
                    val preset = presets[index]
                    val isSelected = preset.id == selectedPresetId

                    CyberCard(
                        borderColor = if (isSelected) NeonCyan else CyberCardBorder,
                        shapeRadius = 14.dp,
                        modifier = Modifier.clickable { selectedPresetId = preset.id }
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isSelected) NeonCyan else CyberSurfaceVariant
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isSelected) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                tint = CyberBackground,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = preset.title,
                                        fontFamily = RajdhaniFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 17.sp,
                                        color = if (isSelected) NeonCyan else TextWhitePrimary
                                    )
                                }
                                StatusBadge(
                                    text = preset.targetDeviceTag,
                                    accentColor = if (isSelected) NeonCyan else TextGrayMuted,
                                    isPulsing = false
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "Booster Actions Applied:",
                                fontFamily = ChakraPetchFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = TextGraySecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            preset.boosterActions.forEach { action ->
                                Text(
                                    text = "• $action",
                                    fontFamily = ChakraPetchFontFamily,
                                    fontSize = 12.sp,
                                    color = TextWhitePrimary
                                )
                            }
                        }
                    }
                }
            }

            1 -> {
                // Tab 1: Map and Visual Customization
                item {
                    CyberCard(
                        borderColor = FieryOrange.copy(alpha = 0.4f),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = FieryOrange,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "Display Color Matrix Layer: Adjusts screen contrast and tone curves externally. Zero game file injection, zero anti-cheat risk.",
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 11.sp,
                                color = TextGraySecondary
                            )
                        }
                    }
                }

                // Interactive Before / After Preview Canvas
                item {
                    CyberCard(
                        borderColor = NeonCyan.copy(alpha = 0.6f)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "BEFORE VS AFTER VISUAL PREVIEW",
                                    fontFamily = RajdhaniFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    letterSpacing = 1.sp,
                                    color = NeonCyan
                                )
                                Text(
                                    text = "SPLIT: ${(previewSplitRatio * 100).toInt()}%",
                                    fontFamily = ChakraPetchFontFamily,
                                    fontSize = 11.sp,
                                    color = TextGraySecondary
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Interactive Battlefield Simulation Canvas
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(1.dp, CyberCardBorder, RoundedCornerShape(12.dp))
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    if (size.width <= 0f || size.height <= 0f) return@Canvas
                                    val splitX = (size.width * previewSplitRatio).coerceIn(0f, size.width)

                                    // Left side: Standard (Default dull potato screen)
                                    drawRect(
                                        color = Color(0xFF1E2822),
                                        topLeft = Offset.Zero,
                                        size = Size(splitX, size.height)
                                    )
                                    // Standard River & Bushes
                                    drawCircle(
                                        color = Color(0xFF263D30),
                                        radius = 45f,
                                        center = Offset(splitX * 0.35f, size.height * 0.45f)
                                    )
                                    drawCircle(
                                        color = Color(0xFF1C423B),
                                        radius = 35f,
                                        center = Offset(splitX * 0.65f, size.height * 0.65f)
                                    )

                                    // Right side: Enhanced Map Preset
                                    val filterColor = Color(activeMap.colorFilterHex)
                                    drawRect(
                                        color = Color(0xFF0F181B),
                                        topLeft = Offset(splitX, 0f),
                                        size = Size(size.width - splitX, size.height)
                                    )
                                    // High contrast bush & river highlights
                                    drawCircle(
                                        color = filterColor.copy(alpha = 0.55f),
                                        radius = 50f,
                                        center = Offset(splitX + (size.width - splitX) * 0.45f, size.height * 0.45f)
                                    )
                                    drawCircle(
                                        color = NeonGreen.copy(alpha = 0.45f),
                                        radius = 38f,
                                        center = Offset(splitX + (size.width - splitX) * 0.75f, size.height * 0.65f)
                                    )

                                    // Split separator line
                                    drawLine(
                                        color = NeonCyan,
                                        start = Offset(splitX, 0f),
                                        end = Offset(splitX, size.height),
                                        strokeWidth = 3.dp.toPx()
                                    )
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "STANDARD DULL",
                                        fontFamily = ChakraPetchFontFamily,
                                        fontSize = 10.sp,
                                        color = TextGrayMuted,
                                        modifier = Modifier
                                            .background(CyberBackground.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                    Text(
                                        text = "BOOSTER CLARITY",
                                        fontFamily = ChakraPetchFontFamily,
                                        fontSize = 10.sp,
                                        color = NeonCyan,
                                        modifier = Modifier
                                            .background(CyberBackground.copy(alpha = 0.8f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Split slider
                            Slider(
                                value = previewSplitRatio,
                                onValueChange = { previewSplitRatio = it },
                                valueRange = 0.1f..0.9f,
                                colors = SliderDefaults.colors(
                                    thumbColor = NeonCyan,
                                    activeTrackColor = NeonCyan,
                                    inactiveTrackColor = CyberSurfaceVariant
                                )
                            )
                        }
                    }
                }

                // Map Theme Presets
                item {
                    Text(
                        text = "MAP APPEARANCE PRESETS",
                        fontFamily = RajdhaniFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        letterSpacing = 1.sp,
                        color = NeonCyan
                    )
                }

                items(mapThemes.size) { idx ->
                    val theme = mapThemes[idx]
                    val isSelected = theme.id == selectedMapId

                    CyberCard(
                        borderColor = if (isSelected) Color(theme.colorFilterHex) else CyberCardBorder,
                        modifier = Modifier.clickable {
                            selectedMapId = theme.id
                            viewModel.settingsRepo.updateMapTheme(theme.id, theme.brightnessMultiplier, theme.contrastBoost)
                            viewModel.showToast("Applied Map Theme: ${theme.title}")
                        }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = theme.title,
                                    fontFamily = RajdhaniFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = if (isSelected) Color(theme.colorFilterHex) else TextWhitePrimary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = theme.description,
                                    fontFamily = ChakraPetchFontFamily,
                                    fontSize = 11.sp,
                                    color = TextGraySecondary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Benefit: ${theme.potatoPerks}",
                                    fontFamily = ChakraPetchFontFamily,
                                    fontSize = 11.sp,
                                    color = NeonGreen
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .padding(start = 12.dp)
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isSelected) Color(theme.colorFilterHex) else CyberSurfaceVariant
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = CyberBackground,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            2 -> {
                // Tab 2: In-Game Settings Guide for Potato Devices
                item {
                    CyberCard(
                        borderColor = GoldenYellow.copy(alpha = 0.5f)
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = null,
                                    tint = GoldenYellow,
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = "OFFICIAL IN-GAME POTATO CONFIGURATION",
                                    fontFamily = RajdhaniFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = GoldenYellow
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Apply these exact toggles inside Mobile Legends Settings > Basics for the highest possible frame stability:",
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 11.sp,
                                color = TextGraySecondary
                            )
                        }
                    }
                }

                items(activePreset.inGameSettings.size) { index ->
                    val (settingName, recommendedValue) = activePreset.inGameSettings[index]
                    CyberCard(
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = settingName,
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp,
                                color = TextWhitePrimary
                            )
                            StatusBadge(
                                text = recommendedValue,
                                accentColor = if (recommendedValue.contains("OFF")) FieryRed else NeonGreen,
                                isPulsing = false
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
