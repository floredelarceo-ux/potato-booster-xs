package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeviceThermostat
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CyberCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.ChakraPetchFontFamily
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.FieryOrange
import com.example.ui.theme.FieryRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TextGrayMuted
import com.example.ui.theme.TextGraySecondary
import com.example.ui.theme.TextWhitePrimary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun SettingsScreen(
    viewModel: MainViewModel
) {
    val settings by viewModel.settings.collectAsState()
    val shizuku by viewModel.shizukuState.collectAsState()
    val stats by viewModel.systemStats.collectAsState()

    var showResetDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            SectionHeader(
                title = "Booster Preferences",
                subtitle = "Automation, thermal guard limits, and Shizuku guide"
            )
        }

        // Automation Toggles
        item {
            CyberCard(
                borderColor = CyberCardBorder
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = "GAMEPLAY AUTOMATION",
                        fontFamily = RajdhaniFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        letterSpacing = 1.sp,
                        color = NeonCyan
                    )

                    // Auto Boost
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Auto Boost When Launching MLBB",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = TextWhitePrimary
                            )
                            Text(
                                text = "Automatically frees RAM and applies gaming profile before game launch",
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 11.sp,
                                color = TextGraySecondary
                            )
                        }
                        Switch(
                            checked = settings.autoBoostOnLaunch,
                            onCheckedChange = { viewModel.settingsRepo.updateAutoBoost(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyberBackground,
                                checkedTrackColor = NeonCyan
                            ),
                            modifier = Modifier.testTag("toggle_auto_boost")
                        )
                    }

                    // Auto Restore
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Auto Restore After Game Exit",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = TextWhitePrimary
                            )
                            Text(
                                text = "Restores standard system refresh rate and background priority after gaming",
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 11.sp,
                                color = TextGraySecondary
                            )
                        }
                        Switch(
                            checked = settings.autoRestoreOnExit,
                            onCheckedChange = { viewModel.settingsRepo.updateAutoRestore(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyberBackground,
                                checkedTrackColor = NeonCyan
                            ),
                            modifier = Modifier.testTag("toggle_auto_restore")
                        )
                    }

                    // Keep Screen Awake
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Keep Screen Awake (WakeLock)",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = TextWhitePrimary
                            )
                            Text(
                                text = "Prevents display timeout during matchmaking and loading screens",
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 11.sp,
                                color = TextGraySecondary
                            )
                        }
                        Switch(
                            checked = settings.keepScreenAwake,
                            onCheckedChange = { viewModel.settingsRepo.updateKeepScreenAwake(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyberBackground,
                                checkedTrackColor = NeonCyan
                            ),
                            modifier = Modifier.testTag("toggle_keep_awake")
                        )
                    }

                    // Gaming DND
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Gaming DND Notification Alert",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = TextWhitePrimary
                            )
                            Text(
                                text = "Recommends muting heads-up popups during ranked matches",
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 11.sp,
                                color = TextGraySecondary
                            )
                        }
                        Switch(
                            checked = settings.gamingModeDndReminder,
                            onCheckedChange = { viewModel.settingsRepo.updateGamingDnd(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyberBackground,
                                checkedTrackColor = NeonCyan
                            ),
                            modifier = Modifier.testTag("toggle_gaming_dnd")
                        )
                    }
                }
            }
        }

        // Thermal Alert Threshold
        item {
            CyberCard(
                borderColor = CyberCardBorder
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "BATTERY TEMPERATURE WARNING",
                            fontFamily = RajdhaniFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            letterSpacing = 1.sp,
                            color = FieryOrange
                        )
                        Text(
                            text = "${settings.batteryTempWarningThreshold}°C",
                            fontFamily = RajdhaniFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = FieryOrange
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Current Battery: ${stats.batteryTempCelsius}°C. Warns you when phone gets hot before SoC drops FPS to 30.",
                        fontFamily = ChakraPetchFontFamily,
                        fontSize = 11.sp,
                        color = TextGraySecondary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Slider(
                        value = settings.batteryTempWarningThreshold.toFloat(),
                        onValueChange = { viewModel.settingsRepo.updateTempThreshold(it.toInt()) },
                        valueRange = 38f..48f,
                        steps = 9,
                        colors = SliderDefaults.colors(
                            thumbColor = FieryOrange,
                            activeTrackColor = FieryOrange,
                            inactiveTrackColor = CyberSurfaceVariant
                        )
                    )
                }
            }
        }

        // Shizuku Integration & Setup Guide
        item {
            CyberCard(
                borderColor = if (shizuku.canExecuteElevated) NeonGreen.copy(alpha = 0.5f) else FieryOrange.copy(alpha = 0.5f)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = if (shizuku.canExecuteElevated) NeonGreen else FieryOrange,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "SHIZUKU INTEGRATION GUIDE",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = TextWhitePrimary
                            )
                        }
                        StatusBadge(
                            text = if (shizuku.canExecuteElevated) "CONNECTED" else "DISCONNECTED",
                            accentColor = if (shizuku.canExecuteElevated) NeonGreen else FieryOrange,
                            isPulsing = !shizuku.canExecuteElevated
                        )
                    }

                    Text(
                        text = shizuku.statusMessage,
                        fontFamily = ChakraPetchFontFamily,
                        fontSize = 11.sp,
                        color = if (shizuku.canExecuteElevated) NeonGreen else TextGraySecondary
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberSurfaceVariant)
                            .padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "How Shizuku Empowers Potato Devices:",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = NeonCyan
                            )
                            Text(
                                text = "• MODE A (Without Shizuku): 100% of standard features work (RAM clearing, storage optimization, map color tuning, profile guidance).",
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 11.sp,
                                color = TextWhitePrimary
                            )
                            Text(
                                text = "• MODE B (With Shizuku): Unlocks elevated Android system commands (AOT Dex compilation for MLBB, direct display refresh rate lock, Hardware Overlay forcing).",
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 11.sp,
                                color = TextWhitePrimary
                            )
                            Text(
                                text = "• How to start: Open Shizuku app -> Start via Wireless Debugging (Android 11+) or connect to PC via ADB once.",
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 11.sp,
                                color = TextGraySecondary
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.requestShizukuPermission() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (shizuku.canExecuteElevated) NeonGreen else FieryOrange,
                                contentColor = CyberBackground
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("shizuku_connect_btn")
                        ) {
                            Text(
                                text = if (shizuku.canExecuteElevated) "VERIFY BINDER" else "CONNECT SHIZUKU",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        OutlinedButton(
                            onClick = { viewModel.openShizukuApp() },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("shizuku_app_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.OpenInNew,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "SHIZUKU APP",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Diagnostics Card
        item {
            CyberCard(
                borderColor = CyberCardBorder
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "HARDWARE & SYSTEM SPECIFICATIONS",
                        fontFamily = RajdhaniFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        letterSpacing = 1.sp,
                        color = NeonCyan
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "• Model: ${stats.manufacturer} ${stats.deviceModel}",
                        fontFamily = ChakraPetchFontFamily,
                        fontSize = 12.sp,
                        color = TextWhitePrimary
                    )
                    Text(
                        text = "• Android Release: ${stats.androidVersion} (API Level ${stats.apiLevel})",
                        fontFamily = ChakraPetchFontFamily,
                        fontSize = 12.sp,
                        color = TextWhitePrimary
                    )
                    Text(
                        text = "• SoC Platform: ${stats.socHardware} (${stats.cpuCores} active cores)",
                        fontFamily = ChakraPetchFontFamily,
                        fontSize = 12.sp,
                        color = TextWhitePrimary
                    )
                    Text(
                        text = "• Physical RAM: ${stats.totalRamMb} MB (${stats.availableRamMb} MB free)",
                        fontFamily = ChakraPetchFontFamily,
                        fontSize = 12.sp,
                        color = TextWhitePrimary
                    )
                    Text(
                        text = "• Internal Storage: ${stats.totalStorageGb} GB (${stats.freeStorageGb} GB free)",
                        fontFamily = ChakraPetchFontFamily,
                        fontSize = 12.sp,
                        color = TextWhitePrimary
                    )
                    Text(
                        text = "• Battery State: ${stats.batteryLevel}% • ${stats.batteryTempCelsius}°C • ${stats.batteryHealth}",
                        fontFamily = ChakraPetchFontFamily,
                        fontSize = 12.sp,
                        color = TextWhitePrimary
                    )
                    Text(
                        text = "• Display Refresh: ${stats.currentRefreshRate.toInt()}Hz (Supported: ${stats.supportedRefreshRates.joinToString { "${it.toInt()}Hz" }})",
                        fontFamily = ChakraPetchFontFamily,
                        fontSize = 12.sp,
                        color = TextWhitePrimary
                    )
                }
            }
        }

        // Factory Reset Settings Button
        item {
            OutlinedButton(
                onClick = { showResetDialog = true },
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = FieryRed
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("reset_all_settings_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.RestartAlt,
                    contentDescription = null,
                    tint = FieryRed
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "RESET ALL BOOSTER SETTINGS",
                    fontFamily = RajdhaniFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = FieryRed
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            containerColor = CyberSurface,
            title = {
                Text(
                    text = "Reset All Settings?",
                    fontFamily = RajdhaniFontFamily,
                    fontWeight = FontWeight.Bold,
                    color = TextWhitePrimary
                )
            },
            text = {
                Text(
                    text = "This will restore default performance profiles, automation toggles, and module configurations.",
                    fontFamily = ChakraPetchFontFamily,
                    color = TextGraySecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.restoreDefaults()
                        showResetDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = FieryRed,
                        contentColor = TextWhitePrimary
                    )
                ) {
                    Text(text = "RESET", fontFamily = RajdhaniFontFamily, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showResetDialog = false }) {
                    Text(text = "CANCEL", fontFamily = RajdhaniFontFamily)
                }
            }
        )
    }
}
