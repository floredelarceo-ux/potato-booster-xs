package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ModuleCategory
import com.example.ui.components.CyberCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.ChakraPetchFontFamily
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.FieryOrange
import com.example.ui.theme.FieryRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TextGrayMuted
import com.example.ui.theme.TextGraySecondary
import com.example.ui.theme.TextWhitePrimary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun ModulesScreen(
    viewModel: MainViewModel
) {
    val modules by viewModel.modules.collectAsState()
    val selectedCategory by viewModel.selectedModuleCategory.collectAsState()
    val backupStatus by viewModel.backupStatus.collectAsState()
    val shizuku by viewModel.shizukuState.collectAsState()

    val filteredModules = if (selectedCategory == null) {
        modules
    } else {
        modules.filter { it.category == selectedCategory }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            SectionHeader(
                title = "Performance Modules",
                subtitle = "Safe configuration packages for low-memory Android gaming"
            )
        }

        // Backup and Restore Ribbon
        item {
            CyberCard(
                borderColor = NeonPurple.copy(alpha = 0.5f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "CONFIGURATION SNAPSHOT",
                            fontFamily = RajdhaniFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = NeonPurple
                        )
                        Text(
                            text = backupStatus,
                            fontFamily = ChakraPetchFontFamily,
                            fontSize = 11.sp,
                            color = TextGraySecondary
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { viewModel.createBackup() },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("backup_modules_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Backup,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "BACKUP",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }

                        OutlinedButton(
                            onClick = { viewModel.restoreDefaults() },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("restore_modules_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Restore,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "RESTORE",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // Category Filter Chips (Horizontal Scroll)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedCategory == null,
                    onClick = { viewModel.selectModuleCategory(null) },
                    label = {
                        Text(
                            text = "ALL (${modules.size})",
                            fontFamily = RajdhaniFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NeonCyan,
                        selectedLabelColor = CyberBackground,
                        containerColor = CyberSurface,
                        labelColor = TextWhitePrimary
                    )
                )

                ModuleCategory.entries.forEach { cat ->
                    val isSelected = selectedCategory == cat
                    val count = modules.count { it.category == cat }
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectModuleCategory(cat) },
                        label = {
                            Text(
                                text = "${cat.label} ($count)",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonCyan,
                            selectedLabelColor = CyberBackground,
                            containerColor = CyberSurface,
                            labelColor = TextWhitePrimary
                        )
                    )
                }
            }
        }

        // Module Items List
        items(filteredModules.size) { index ->
            val module = filteredModules[index]

            CyberCard(
                borderColor = if (module.isEnabled) NeonGreen.copy(alpha = 0.5f) else CyberCardBorder
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = module.name,
                                    fontFamily = RajdhaniFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = if (module.isEnabled) NeonGreen else TextWhitePrimary
                                )
                            }
                            Text(
                                text = module.category.label,
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 11.sp,
                                color = TextGrayMuted
                            )
                        }

                        // Enable/Disable Switch (only if installed and compatible)
                        if (module.isInstalled && !module.requiresRoot) {
                            Switch(
                                checked = module.isEnabled,
                                onCheckedChange = { viewModel.toggleModule(module.id) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = CyberBackground,
                                    checkedTrackColor = NeonGreen,
                                    uncheckedThumbColor = TextGraySecondary,
                                    uncheckedTrackColor = CyberSurfaceVariant
                                ),
                                modifier = Modifier.testTag("toggle_${module.id}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = module.summary,
                        fontFamily = ChakraPetchFontFamily,
                        fontSize = 12.sp,
                        color = TextGraySecondary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = module.details,
                        fontFamily = ChakraPetchFontFamily,
                        fontSize = 11.sp,
                        color = TextWhitePrimary.copy(alpha = 0.85f)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Badges row: Requirements, Impact, Compatibility
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (module.requiresRoot) {
                                StatusBadge(
                                    text = "ROOT REQUIRED",
                                    accentColor = FieryRed,
                                    isPulsing = false
                                )
                            } else if (module.requiresShizuku) {
                                StatusBadge(
                                    text = if (shizuku.canExecuteElevated) "SHIZUKU ACTIVE" else "SHIZUKU NEEDED",
                                    accentColor = if (shizuku.canExecuteElevated) NeonCyan else FieryOrange,
                                    isPulsing = false
                                )
                            } else {
                                StatusBadge(
                                    text = "STANDARD COMPLIANT",
                                    accentColor = NeonGreen,
                                    isPulsing = false
                                )
                            }

                            StatusBadge(
                                text = "IMPACT: ${module.impactRating.uppercase()}",
                                accentColor = when (module.impactRating) {
                                    "Extreme" -> FieryOrange
                                    "High" -> NeonCyan
                                    else -> NeonGreen
                                },
                                isPulsing = false
                            )
                        }

                        // Install / Uninstall Actions
                        if (module.requiresRoot) {
                            Text(
                                text = "LOCKED (NO ROOT)",
                                fontFamily = ChakraPetchFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = FieryRed
                            )
                        } else if (!module.isInstalled) {
                            Button(
                                onClick = { viewModel.installModule(module.id) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NeonCyan,
                                    contentColor = CyberBackground
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("install_${module.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "INSTALL",
                                    fontFamily = RajdhaniFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        } else {
                            Text(
                                text = "INSTALLED",
                                fontFamily = ChakraPetchFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = NeonGreen
                            )
                        }
                    }

                    if (module.appliedConfigSummary.isNotEmpty() && module.isEnabled) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(CyberSurfaceVariant)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Applied: ${module.appliedConfigSummary}",
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 10.sp,
                                color = TextGrayMuted
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
