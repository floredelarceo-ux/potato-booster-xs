package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProfileType
import com.example.ui.components.CircularPerformanceGauge
import com.example.ui.components.CyberCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.ChakraPetchFontFamily
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.FieryOrange
import com.example.ui.theme.FieryRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TextGrayMuted
import com.example.ui.theme.TextGraySecondary
import com.example.ui.theme.TextWhitePrimary
import com.example.ui.viewmodel.MainViewModel

@Composable
fun PerformanceScreen(
    viewModel: MainViewModel
) {
    val stats by viewModel.systemStats.collectAsState()
    val shizuku by viewModel.shizukuState.collectAsState()
    val settings by viewModel.settings.collectAsState()

    val supportedRates = stats.supportedRefreshRates

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            SectionHeader(
                title = "FPS & Performance Center",
                subtitle = "Hardware render pacing and display refresh manager"
            )
        }

        // Live FPS & Frame Pacing Telemetry
        item {
            CyberCard(
                borderColor = NeonCyan.copy(alpha = 0.5f)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(NeonGreen)
                            )
                            Text(
                                text = "LIVE VSYNC FPS MONITOR",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = TextWhitePrimary
                            )
                        }
                        StatusBadge(
                            text = "${stats.currentRefreshRate.toInt()} HZ VSYNC",
                            accentColor = NeonCyan,
                            isPulsing = false
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = String.format("%.1f", stats.currentFps),
                                    fontFamily = RajdhaniFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 42.sp,
                                    color = TextWhitePrimary
                                )
                                Text(
                                    text = " FPS",
                                    fontFamily = ChakraPetchFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = NeonCyan,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )
                            }
                            Text(
                                text = "Target: ${stats.currentRefreshRate.toInt()} FPS • Avg: ${stats.avgFps} FPS",
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 12.sp,
                                color = TextGraySecondary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${stats.frameTimeMs} ms",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 24.sp,
                                color = if (stats.frameTimeMs <= 18f) NeonGreen else FieryOrange
                            )
                            Text(
                                text = "Frame Time Interval",
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 11.sp,
                                color = TextGrayMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Live Frame-Time Waveform Graph
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(70.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberSurfaceVariant.copy(alpha = 0.5f))
                            .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            if (size.width <= 0f || size.height <= 0f) return@Canvas
                            val path = Path()
                            val points = 24
                            val stepX = size.width / (points - 1)
                            val baseHeight = size.height * 0.5f

                            for (i in 0 until points) {
                                val jitter = ((i * 37) % 17 - 8).toFloat()
                                val x = i * stepX
                                val y = (baseHeight + jitter).coerceIn(10f, size.height - 10f)
                                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                            }

                            drawPath(
                                path = path,
                                color = NeonCyan,
                                style = Stroke(width = 2.dp.toPx())
                            )
                        }

                        Text(
                            text = "SMOOTH FRAME-PACING BUFFER",
                            fontFamily = ChakraPetchFontFamily,
                            fontSize = 9.sp,
                            color = TextGrayMuted,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(6.dp)
                        )
                    }
                }
            }
        }

        // Refresh Rate Manager
        item {
            CyberCard(
                borderColor = CyberCardBorder
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DisplaySettings,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "REFRESH RATE MANAGER",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = TextWhitePrimary
                            )
                        }
                        Text(
                            text = "MAX: ${supportedRates.maxOrNull()?.toInt() ?: 60}Hz",
                            fontFamily = ChakraPetchFontFamily,
                            fontSize = 11.sp,
                            color = NeonCyan
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Hardware Detection: Options unsupported by this device's physical panel are automatically disabled. A 60Hz panel cannot become 120Hz via software.",
                        fontFamily = ChakraPetchFontFamily,
                        fontSize = 11.sp,
                        color = TextGraySecondary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    val standardRates = listOf(60f, 90f, 120f, 144f)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        standardRates.forEach { rate ->
                            val isSupported = supportedRates.any { kotlin.math.abs(it - rate) < 2f }
                            val isCurrent = kotlin.math.abs(stats.currentRefreshRate - rate) < 2f

                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable(enabled = isSupported) {
                                        viewModel.setRefreshRate(rate)
                                    }
                                    .border(
                                        width = if (isCurrent) 1.5.dp else 1.dp,
                                        color = when {
                                            isCurrent -> NeonCyan
                                            isSupported -> CyberCardBorder
                                            else -> Color.DarkGray
                                        },
                                        shape = RoundedCornerShape(10.dp)
                                    ),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = when {
                                        isCurrent -> NeonCyan.copy(alpha = 0.15f)
                                        isSupported -> CyberSurface
                                        else -> CyberSurface.copy(alpha = 0.4f)
                                    }
                                )
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 12.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "${rate.toInt()}Hz",
                                        fontFamily = RajdhaniFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = when {
                                            isCurrent -> NeonCyan
                                            isSupported -> TextWhitePrimary
                                            else -> TextGrayMuted
                                        }
                                    )
                                    Text(
                                        text = when {
                                            isCurrent -> "ACTIVE"
                                            isSupported -> "READY"
                                            else -> "LOCKED"
                                        },
                                        fontFamily = ChakraPetchFontFamily,
                                        fontSize = 9.sp,
                                        color = when {
                                            isCurrent -> NeonCyan
                                            isSupported -> NeonGreen
                                            else -> TextGrayMuted
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (shizuku.canExecuteElevated) {
                                "Shizuku Shell: Direct system setting write active"
                            } else {
                                "Standard Mode: Modifies app display preference"
                            },
                            fontFamily = ChakraPetchFontFamily,
                            fontSize = 11.sp,
                            color = TextGraySecondary
                        )

                        OutlinedButton(
                            onClick = { viewModel.openDisplaySettings() },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("system_display_btn")
                        ) {
                            Text(
                                text = "SYSTEM SETTINGS",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // Performance Profiles
        item {
            Text(
                text = "PERFORMANCE PROFILES",
                fontFamily = RajdhaniFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                letterSpacing = 1.sp,
                color = NeonCyan
            )
        }

        items(viewModel.performanceProfiles.size) { index ->
            val profile = viewModel.performanceProfiles[index]
            val isSelected = settings.selectedProfile == profile.id

            CyberCard(
                borderColor = if (isSelected) profile.accentColor else CyberCardBorder,
                modifier = Modifier.clickable {
                    viewModel.settingsRepo.updateProfile(profile.id)
                    viewModel.showToast("Selected Profile: ${profile.title}")
                }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = profile.title,
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = if (isSelected) profile.accentColor else TextWhitePrimary
                            )
                            StatusBadge(
                                text = profile.badge,
                                accentColor = profile.accentColor,
                                isPulsing = isSelected
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = profile.description,
                            fontFamily = ChakraPetchFontFamily,
                            fontSize = 11.sp,
                            color = TextGraySecondary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "RAM: ${profile.ramAggressiveness}",
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 10.sp,
                                color = TextGrayMuted
                            )
                            Text(
                                text = "Thermal: <${profile.thermalLimitCelsius}°C",
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 10.sp,
                                color = TextGrayMuted
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .padding(start = 10.dp)
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) profile.accentColor else CyberSurfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = CyberBackground,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
