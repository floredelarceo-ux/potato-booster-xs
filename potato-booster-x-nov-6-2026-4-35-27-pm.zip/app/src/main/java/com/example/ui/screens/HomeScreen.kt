package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProfileType
import com.example.ui.components.CircularPerformanceGauge
import com.example.ui.components.CyberCard
import com.example.ui.components.NeonButton
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.ChakraPetchFontFamily
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.FieryOrange
import com.example.ui.theme.FieryRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TextGrayMuted
import com.example.ui.theme.TextGraySecondary
import com.example.ui.theme.TextWhitePrimary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigate: (AppScreen) -> Unit
) {
    val stats by viewModel.systemStats.collectAsState()
    val shizuku by viewModel.shizukuState.collectAsState()
    val settings by viewModel.settings.collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "boost_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "btn_pulse"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Device Specs & Performance Status Header
            CyberCard(
                borderColor = NeonCyan.copy(alpha = 0.4f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "${stats.manufacturer.uppercase()} ${stats.deviceModel.uppercase()}",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = TextWhitePrimary
                            )
                            StatusBadge(
                                text = "ANDROID ${stats.androidVersion}",
                                accentColor = NeonCyan,
                                isPulsing = false
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "SoC: ${stats.socHardware} • ${stats.cpuCores} Cores • ${stats.currentRefreshRate.toInt()}Hz Display",
                            fontFamily = ChakraPetchFontFamily,
                            fontSize = 11.sp,
                            color = TextGraySecondary
                        )
                    }

                    StatusBadge(
                        text = stats.performanceStatus,
                        accentColor = if (stats.batteryTempCelsius >= 42f) FieryRed else NeonGreen,
                        isPulsing = true
                    )
                }
            }
        }

        // Shizuku Status Banner (Mode A vs Mode B)
        item {
            CyberCard(
                borderColor = if (shizuku.canExecuteElevated) NeonGreen.copy(alpha = 0.6f) else FieryOrange.copy(alpha = 0.5f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (shizuku.canExecuteElevated) NeonGreen.copy(alpha = 0.15f) else FieryOrange.copy(alpha = 0.15f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (shizuku.canExecuteElevated) Icons.Default.CheckCircle else Icons.Default.Security,
                                contentDescription = null,
                                tint = if (shizuku.canExecuteElevated) NeonGreen else FieryOrange,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = if (shizuku.canExecuteElevated) "SHIZUKU CONNECTED (MODE B)" else "STANDARD MODE (MODE A)",
                                    fontFamily = RajdhaniFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = if (shizuku.canExecuteElevated) NeonGreen else FieryOrange
                                )
                            }
                            Text(
                                text = if (shizuku.canExecuteElevated) {
                                    "Elevated DexOpt compilation and system commands unlocked."
                                } else {
                                    "Running safely without Shizuku. Basic RAM & Potato profiles active."
                                },
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 11.sp,
                                color = TextGraySecondary
                            )
                        }
                    }

                    if (!shizuku.canExecuteElevated) {
                        Button(
                            onClick = { viewModel.requestShizukuPermission() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = FieryOrange,
                                contentColor = CyberBackground
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .padding(start = 8.dp)
                                .testTag("shizuku_action_button")
                        ) {
                            Text(
                                text = if (!shizuku.isInstalled) "INSTALL" else "AUTHORIZE",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // Circular Performance Gauges Row
        item {
            CyberCard(
                borderColor = CyberCardBorder
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "REAL-TIME HARDWARE TELEMETRY",
                            fontFamily = RajdhaniFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            letterSpacing = 1.sp,
                            color = NeonCyan
                        )
                        Text(
                            text = "NO SIMULATED METRICS",
                            fontFamily = ChakraPetchFontFamily,
                            fontSize = 10.sp,
                            color = TextGrayMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        CircularPerformanceGauge(
                            value = stats.cpuUsagePercent,
                            maxValue = 100f,
                            label = "CPU Load",
                            unit = "%",
                            accentColor = if (stats.cpuUsagePercent > 75f) FieryRed else NeonCyan,
                            subLabel = "${stats.cpuCores} Cores"
                        )

                        CircularPerformanceGauge(
                            value = stats.usedRamPercent,
                            maxValue = 100f,
                            label = "RAM Used",
                            unit = "%",
                            accentColor = if (stats.usedRamPercent > 80f) FieryOrange else NeonPurple,
                            subLabel = "${stats.availableRamMb}MB Free"
                        )

                        CircularPerformanceGauge(
                            value = stats.batteryTempCelsius,
                            maxValue = 55f,
                            label = "Temp",
                            unit = "°C",
                            accentColor = if (stats.batteryTempCelsius >= 42f) FieryRed else NeonGreen,
                            subLabel = if (stats.isCharging) "Charging" else "${stats.batteryLevel}%"
                        )
                    }
                }
            }
        }

        // Giant Animated BOOST NOW Button
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .scale(pulseScale)
                        .clickable { viewModel.triggerOneTapBoost() }
                        .border(
                            width = 2.dp,
                            brush = Brush.horizontalGradient(
                                colors = listOf(NeonCyan, NeonPurple, FieryOrange, NeonCyan)
                            ),
                            shape = RoundedCornerShape(20.dp)
                        )
                        .testTag("boost_now_button"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = CyberSurfaceVariant
                    )
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        NeonCyan.copy(alpha = 0.22f),
                                        NeonPurple.copy(alpha = 0.15f),
                                        CyberSurface
                                    )
                                )
                            )
                            .padding(vertical = 20.dp, horizontal = 24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(NeonCyan),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bolt,
                                        contentDescription = null,
                                        tint = CyberBackground,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Text(
                                    text = "BOOST NOW",
                                    fontFamily = RajdhaniFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 26.sp,
                                    letterSpacing = 2.sp,
                                    color = TextWhitePrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "One-Tap Low-Memory Reclamation & MLBB Optimization",
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 12.sp,
                                color = NeonCyan
                            )
                        }
                    }
                }
            }
        }

        // MLBB Game Status & Quick Launch
        item {
            CyberCard(
                borderColor = if (stats.isMlbbInstalled) NeonCyan.copy(alpha = 0.5f) else CyberCardBorder
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(NeonPurple.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SportsEsports,
                                contentDescription = null,
                                tint = NeonPurple,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "MOBILE LEGENDS: BANG BANG",
                                    fontFamily = RajdhaniFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = TextWhitePrimary
                                )
                            }
                            Text(
                                text = if (stats.isMlbbInstalled) {
                                    "Installed: ${stats.mlbbVersionName} (${stats.mlbbPackageName})"
                                } else {
                                    "Package not found. Install from Google Play or TapTap."
                                },
                                fontFamily = ChakraPetchFontFamily,
                                fontSize = 11.sp,
                                color = if (stats.isMlbbInstalled) NeonGreen else TextGraySecondary
                            )
                        }
                    }

                    Button(
                        onClick = {
                            if (stats.isMlbbInstalled) {
                                viewModel.launchMLBB()
                            } else {
                                onNavigate(AppScreen.MLBB)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (stats.isMlbbInstalled) NeonGreen else CyberSurfaceVariant,
                            contentColor = CyberBackground
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("launch_mlbb_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (stats.isMlbbInstalled) "LAUNCH" else "PREVIEW",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        // Quick Performance Profile Selector
        item {
            Column {
                SectionHeader(
                    title = "Active Performance Profile",
                    subtitle = "Select hardware bias for game launch",
                    action = {
                        Text(
                            text = "CONFIG",
                            fontFamily = RajdhaniFontFamily,
                            fontWeight = FontWeight.Bold,
                            color = NeonCyan,
                            fontSize = 13.sp,
                            modifier = Modifier.clickable { onNavigate(AppScreen.PERFORMANCE) }
                        )
                    },
                    modifier = Modifier
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    viewModel.performanceProfiles.forEach { profile ->
                        val isSelected = settings.selectedProfile == profile.id
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { viewModel.settingsRepo.updateProfile(profile.id) }
                                .border(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) profile.accentColor else CyberCardBorder,
                                    shape = RoundedCornerShape(12.dp)
                                ),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) profile.accentColor.copy(alpha = 0.12f) else CyberSurface
                            )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp, horizontal = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "${profile.targetFps} FPS",
                                    fontFamily = RajdhaniFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (isSelected) profile.accentColor else TextWhitePrimary
                                )
                                Text(
                                    text = profile.id.name,
                                    fontFamily = ChakraPetchFontFamily,
                                    fontSize = 10.sp,
                                    color = if (isSelected) profile.accentColor else TextGraySecondary
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}
