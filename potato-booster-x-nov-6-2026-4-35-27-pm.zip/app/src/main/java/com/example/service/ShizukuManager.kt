package com.example.service

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import com.example.data.model.ShizukuState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

object ShizukuManager {
    private const val TAG = "PotatoShizuku"
    const val REQUEST_CODE_SHIZUKU_PERMISSION = 7789

    private val _state = MutableStateFlow(
        ShizukuState(
            isInstalled = false,
            isRunning = false,
            isPermissionGranted = false,
            statusMessage = "Standard Mode (Mode A) - Shizuku not connected"
        )
    )
    val state: StateFlow<ShizukuState> = _state.asStateFlow()

    private var isListenersRegistered = false

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        try {
            Log.d(TAG, "Shizuku binder received")
            updateShizukuStateInternal()
        } catch (e: Throwable) {
            Log.w(TAG, "Error in onBinderReceived", e)
        }
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        try {
            Log.d(TAG, "Shizuku binder dead")
            _state.value = _state.value.copy(
                isRunning = false,
                isPermissionGranted = false,
                statusMessage = "Shizuku service disconnected"
            )
        } catch (e: Throwable) {
            Log.w(TAG, "Error in onBinderDead", e)
        }
    }

    private val requestPermissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            try {
                if (requestCode == REQUEST_CODE_SHIZUKU_PERMISSION) {
                    val granted = grantResult == PackageManager.PERMISSION_GRANTED
                    Log.d(TAG, "Shizuku permission result: $granted")
                    updateShizukuStateInternal()
                }
            } catch (e: Throwable) {
                Log.w(TAG, "Error in onRequestPermissionResult", e)
            }
        }

    fun init(context: Context) {
        try {
            val isInstalled = isShizukuAppInstalled(context)
            _state.value = _state.value.copy(isInstalled = isInstalled)

            // In browser preview or emulators without Shizuku app installed,
            // DO NOT attach IPC listeners to prevent binder crash
            if (!isInstalled) {
                _state.value = _state.value.copy(
                    isRunning = false,
                    isPermissionGranted = false,
                    statusMessage = "Standard Mode (Mode A) - Shizuku app not installed"
                )
                return
            }

            // Only attempt listener registration if the app is actually present
            if (!isListenersRegistered) {
                try {
                    Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
                    Shizuku.addBinderDeadListener(binderDeadListener)
                    Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)
                    isListenersRegistered = true
                } catch (e: Throwable) {
                    Log.w(TAG, "Failed to register Shizuku listeners", e)
                }
            }

            updateShizukuState(context)
        } catch (e: Throwable) {
            Log.w(TAG, "Shizuku init error, falling back to Standard Mode", e)
            _state.value = _state.value.copy(
                isInstalled = false,
                isRunning = false,
                isPermissionGranted = false,
                statusMessage = "Standard Mode (Mode A) Active"
            )
        }
    }

    fun destroy() {
        try {
            if (isListenersRegistered) {
                Shizuku.removeBinderReceivedListener(binderReceivedListener)
                Shizuku.removeBinderDeadListener(binderDeadListener)
                Shizuku.removeRequestPermissionResultListener(requestPermissionResultListener)
                isListenersRegistered = false
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Failed to unregister Shizuku listeners", e)
        }
    }

    fun isShizukuAppInstalled(context: Context): Boolean {
        return try {
            val pm = context.packageManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo("moe.shizuku.privileged.api", PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo("moe.shizuku.privileged.api", 0)
            }
            true
        } catch (_: Throwable) {
            false
        }
    }

    fun updateShizukuState(context: Context? = null) {
        try {
            if (context != null) {
                _state.value = _state.value.copy(isInstalled = isShizukuAppInstalled(context))
            }
            if (_state.value.isInstalled) {
                updateShizukuStateInternal()
            } else {
                _state.value = _state.value.copy(
                    isRunning = false,
                    isPermissionGranted = false,
                    statusMessage = "Standard Mode (Mode A) - Shizuku not installed"
                )
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Error updating Shizuku state", e)
        }
    }

    private fun updateShizukuStateInternal() {
        try {
            val isPingOk = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
            if (!isPingOk) {
                _state.value = _state.value.copy(
                    isRunning = false,
                    isPermissionGranted = false,
                    statusMessage = if (_state.value.isInstalled) "Shizuku app detected but service is not running." else "Standard Mode (Mode A)"
                )
                return
            }

            val version = try { Shizuku.getVersion() } catch (_: Throwable) { 0 }
            val uid = try { Shizuku.getUid() } catch (_: Throwable) { -1 }

            val isGranted = try {
                if (Shizuku.isPreV11()) {
                    false
                } else {
                    Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                }
            } catch (e: Throwable) {
                false
            }

            val msg = when {
                !isGranted -> "Shizuku service active. Tap AUTHORIZE to grant access."
                else -> "Shizuku active & authorized (v$version, UID $uid)"
            }

            _state.value = _state.value.copy(
                isRunning = true,
                isPermissionGranted = isGranted,
                version = version,
                uid = uid,
                statusMessage = msg
            )
        } catch (e: Throwable) {
            Log.w(TAG, "Error checking Shizuku binder", e)
            _state.value = _state.value.copy(
                isRunning = false,
                isPermissionGranted = false,
                statusMessage = "Standard Mode (Mode A) Active"
            )
        }
    }

    fun requestPermission(): Boolean {
        return try {
            if (Shizuku.pingBinder() && !Shizuku.isPreV11()) {
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                    Shizuku.requestPermission(REQUEST_CODE_SHIZUKU_PERMISSION)
                    true
                } else {
                    updateShizukuStateInternal()
                    true
                }
            } else {
                false
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Error requesting Shizuku permission", e)
            false
        }
    }

    suspend fun executeElevatedCommand(cmd: String): Result<String> = withContext(Dispatchers.IO) {
        if (!_state.value.canExecuteElevated) {
            return@withContext Result.failure(IllegalStateException("Shizuku is not authorized"))
        }

        try {
            val newProcessMethod = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            newProcessMethod.isAccessible = true
            val process = newProcessMethod.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val errorReader = BufferedReader(InputStreamReader(process.errorStream))
            val output = StringBuilder()

            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.appendLine(line)
            }
            while (errorReader.readLine().also { line = it } != null) {
                output.appendLine("ERR: $line")
            }

            process.waitFor()
            reader.close()
            errorReader.close()

            Result.success(output.toString().trim())
        } catch (e: Throwable) {
            Log.e(TAG, "Error running command: $cmd", e)
            Result.failure(e)
        }
    }
}
