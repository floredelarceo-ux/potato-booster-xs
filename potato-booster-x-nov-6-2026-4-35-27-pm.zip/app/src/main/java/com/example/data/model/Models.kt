package com.example.data.model

import androidx.compose.ui.graphics.Color

data class SystemStats(
    val deviceModel: String = "Unknown",
    val manufacturer: String = "Generic",
    val androidVersion: String = "14",
    val apiLevel: Int = 34,
    val socHardware: String = "ARM64",
    val cpuCores: Int = 8,
    val cpuUsagePercent: Float = 24.5f,
    val totalRamMb: Long = 4096L,
    val availableRamMb: Long = 1840L,
    val usedRamPercent: Float = 55.0f,
    val totalStorageGb: Float = 64.0f,
    val freeStorageGb: Float = 22.4f,
    val usedStoragePercent: Float = 65.0f,
    val batteryTempCelsius: Float = 33.5f,
    val batteryLevel: Int = 85,
    val isCharging: Boolean = false,
    val batteryHealth: String = "Good",
    val currentRefreshRate: Float = 60f,
    val supportedRefreshRates: List<Float> = listOf(60f),
    val currentFps: Float = 59.8f,
    val avgFps: Float = 58.4f,
    val frameTimeMs: Float = 16.7f,
    val isMlbbInstalled: Boolean = false,
    val mlbbPackageName: String = "com.mobile.legends",
    val mlbbVersionName: String = "Not Installed",
    val performanceStatus: String = "POTATO MODE READY",
    val lastBoostTime: String = "Never"
)

data class ShizukuState(
    val isInstalled: Boolean = false,
    val isRunning: Boolean = false,
    val isPermissionGranted: Boolean = false,
    val version: Int = 0,
    val uid: Int = -1,
    val statusMessage: String = "Checking Shizuku API..."
) {
    val canExecuteElevated: Boolean
        get() = isRunning && isPermissionGranted
}

enum class ProfileType {
    POTATO,
    BALANCED,
    PERFORMANCE,
    EXTREME
}

data class PerformanceProfile(
    val id: ProfileType,
    val title: String,
    val badge: String,
    val description: String,
    val targetFps: Int,
    val accentColor: Color,
    val ramAggressiveness: String,
    val cpuScheduling: String,
    val thermalLimitCelsius: Int,
    val dexOptPriority: Boolean
)

enum class ModuleCategory(val label: String, val iconName: String) {
    RAM("RAM Optimization", "Memory"),
    CPU_SCHEDULING("CPU Scheduling", "Speed"),
    TOUCH("Touch Response", "TouchApp"),
    NETWORK("Network Optimization", "Wifi"),
    THERMAL("Thermal Management", "DeviceThermostat"),
    DISPLAY("Display Optimization", "ScreenshotMonitor"),
    BACKGROUND_PROCESSES("Background Process", "PowerSettingsNew")
}

data class OptimizationModule(
    val id: String,
    val name: String,
    val category: ModuleCategory,
    val summary: String,
    val details: String,
    val safeForPotato: Boolean = true,
    val requiresShizuku: Boolean = false,
    val requiresRoot: Boolean = false,
    val isInstalled: Boolean = false,
    val isEnabled: Boolean = false,
    val impactRating: String = "High",
    val appliedConfigSummary: String = ""
)

data class MLBBGraphicPreset(
    val id: String,
    val title: String,
    val targetDeviceTag: String,
    val recommendedRam: String,
    val targetFps: Int,
    val inGameSettings: List<Pair<String, String>>,
    val boosterActions: List<String>
)

data class MapThemePreset(
    val id: String,
    val title: String,
    val mapName: String,
    val description: String,
    val colorFilterHex: Long,
    val contrastBoost: Float,
    val brightnessMultiplier: Float,
    val saturationMultiplier: Float,
    val potatoPerks: String
)

enum class StepStatus {
    PENDING,
    RUNNING,
    COMPLETED,
    SKIPPED_NO_SHIZUKU,
    WARNING
}

data class BoostStep(
    val stepIndex: Int,
    val title: String,
    val description: String,
    val status: StepStatus = StepStatus.PENDING,
    val requiresShizuku: Boolean = false,
    val detail: String = ""
)

data class BoostReport(
    val ramFreedMb: Long,
    val ramBeforeMb: Long,
    val ramAfterMb: Long,
    val processesTrimmed: Int,
    val stepsCompleted: Int,
    val stepsSkipped: Int,
    val appliedProfile: String,
    val executedAtMillis: Long = System.currentTimeMillis()
)
