package com.example.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.ModuleCategory
import com.example.data.model.OptimizationModule
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "potato_booster_prefs")

class ModuleRepository(private val context: Context) {

    private val defaultModules = listOf(
        // RAM
        OptimizationModule(
            id = "mod_lmk_tune",
            name = "Aggressive LMK Tuning",
            category = ModuleCategory.RAM,
            summary = "Forces low memory killer to release cached background apps immediately for MLBB.",
            details = "Lowers lowmemorykiller thresholds so background apps do not steal RAM during team fights on 2GB-4GB devices.",
            safeForPotato = true,
            requiresShizuku = false,
            requiresRoot = false,
            isInstalled = true,
            isEnabled = true,
            impactRating = "High",
            appliedConfigSummary = "sys.lmk.minfree = tuned for 3GB potato allocation"
        ),
        OptimizationModule(
            id = "mod_zram_swap",
            name = "ZRAM Swap Allocator Assist",
            category = ModuleCategory.RAM,
            summary = "Optimizes swap cache compression ratio to prevent out-of-memory game crashes.",
            details = "Adjusts swappiness and virtual memory pressure to allow smoother map asset streaming.",
            safeForPotato = true,
            requiresShizuku = true,
            requiresRoot = false,
            isInstalled = true,
            isEnabled = true,
            impactRating = "High",
            appliedConfigSummary = "vm.swappiness = 80; zram comp = lz4"
        ),

        // CPU Scheduling
        OptimizationModule(
            id = "mod_governor_touch",
            name = "Touch Boost Governor Assist",
            category = ModuleCategory.CPU_SCHEDULING,
            summary = "Elevates CPU frequency instantly upon joystick input to prevent skill-cast lag.",
            details = "Reduces time-to-max-clock on low-end CPUs like Helio P35, Snapdragon 665, and Unisoc chips.",
            safeForPotato = true,
            requiresShizuku = true,
            requiresRoot = false,
            isInstalled = true,
            isEnabled = true,
            impactRating = "Extreme",
            appliedConfigSummary = "cpu.gov.touch_boost = enabled"
        ),
        OptimizationModule(
            id = "mod_big_core",
            name = "Big-Core Affinity Prioritization",
            category = ModuleCategory.CPU_SCHEDULING,
            summary = "Binds Mobile Legends main render thread to performance CPU cores.",
            details = "Prevents Android OS task scheduler from moving MLBB graphics thread to power-saving LITTLE cores. Requires root for cgroup thread pinning.",
            safeForPotato = true,
            requiresShizuku = false,
            requiresRoot = true,
            isInstalled = false,
            isEnabled = false,
            impactRating = "Extreme",
            appliedConfigSummary = "cgroup affinity -> CPU4-CPU7 (ROOT REQUIRED)"
        ),

        // Touch Response
        OptimizationModule(
            id = "mod_touch_buffer",
            name = "Input Event Queue Latency Reducer",
            category = ModuleCategory.TOUCH,
            summary = "Flushes input dispatcher queue to drop touch latency by up to 14ms.",
            details = "Configures touch event coalescing so fast skill combos (e.g. Chou, Fanny, Gusion) register without skipped touches.",
            safeForPotato = true,
            requiresShizuku = false,
            requiresRoot = false,
            isInstalled = true,
            isEnabled = true,
            impactRating = "Medium",
            appliedConfigSummary = "touch.pressure.scale = 0.001; input.latency = min"
        ),
        OptimizationModule(
            id = "mod_tap_response",
            name = "Sampling Rate Jitter Stabilizer",
            category = ModuleCategory.TOUCH,
            summary = "Eliminates touch deadzone jitter along screen edges and corners.",
            details = "Calibrates digitizer sampling interval consistency for smoother analog stick panning.",
            safeForPotato = true,
            requiresShizuku = false,
            requiresRoot = false,
            isInstalled = true,
            isEnabled = false,
            impactRating = "Safe",
            appliedConfigSummary = "touch.filter.level = responsive"
        ),

        // Network Optimization
        OptimizationModule(
            id = "mod_dns_cache",
            name = "DNS Cache Pre-Warming",
            category = ModuleCategory.NETWORK,
            summary = "Pre-resolves regional Moonton game servers to minimize matchmaking ping spikes.",
            details = "Maintains warmed local DNS entries for SEA, Indo, PH, LatAm, and Europe MLBB battle nodes.",
            safeForPotato = true,
            requiresShizuku = false,
            requiresRoot = false,
            isInstalled = true,
            isEnabled = true,
            impactRating = "Safe",
            appliedConfigSummary = "DNS cache TTL = 3600s; target = mlbb.moonton.com"
        ),
        OptimizationModule(
            id = "mod_tcp_latency",
            name = "TCP Low-Latency Game Buffer",
            category = ModuleCategory.NETWORK,
            summary = "Enables TCP Fast Open and adjusts socket buffer sizes for cellular/Wi-Fi data.",
            details = "Reduces ping micro-spikes (e.g. from 120ms to 45ms) when multiple devices share Wi-Fi.",
            safeForPotato = true,
            requiresShizuku = true,
            requiresRoot = false,
            isInstalled = true,
            isEnabled = true,
            impactRating = "High",
            appliedConfigSummary = "net.ipv4.tcp_low_latency = 1"
        ),

        // Thermal Management
        OptimizationModule(
            id = "mod_potato_cool",
            name = "Potato CoolDown Throttling Guard",
            category = ModuleCategory.THERMAL,
            summary = "Pre-regulates frame timing before thermal throttling kicks down GPU clock.",
            details = "Smooths temperature curve to avoid the sudden 60fps -> 25fps thermal drop cliff.",
            safeForPotato = true,
            requiresShizuku = false,
            requiresRoot = false,
            isInstalled = true,
            isEnabled = true,
            impactRating = "Safe",
            appliedConfigSummary = "Thermal curve pacing = active"
        ),
        OptimizationModule(
            id = "mod_battery_temp",
            name = "Adaptive Battery Thermal Sentinel",
            category = ModuleCategory.THERMAL,
            summary = "Monitors real battery temperature and alerts if phone reaches 42°C.",
            details = "Includes quick-cooling advice and auto-lowers background refresh rate during standby.",
            safeForPotato = true,
            requiresShizuku = false,
            requiresRoot = false,
            isInstalled = true,
            isEnabled = true,
            impactRating = "Safe",
            appliedConfigSummary = "Threshold = 42.0°C; auto-protect = ON"
        ),

        // Display Optimization
        OptimizationModule(
            id = "mod_hw_overlay",
            name = "Force Hardware Overlay Composition",
            category = ModuleCategory.DISPLAY,
            summary = "Bypasses VRAM frame-buffer copying by using Hardware Overlays for rendering.",
            details = "Saves GPU fill-rate bandwidth, critical for potato Mali and Adreno 5xx/6xx chipsets.",
            safeForPotato = true,
            requiresShizuku = true,
            requiresRoot = false,
            isInstalled = true,
            isEnabled = true,
            impactRating = "High",
            appliedConfigSummary = "service call SurfaceFlinger 1008 i32 1"
        ),
        OptimizationModule(
            id = "mod_frame_pacing",
            name = "Frame Pacing Jitter Stabilizer",
            category = ModuleCategory.DISPLAY,
            summary = "Synchronizes Android VSync with MLBB display swapchain.",
            details = "Reduces screen tearing and micro-stutter when Lord and 10 heroes clash simultaneously.",
            safeForPotato = true,
            requiresShizuku = false,
            requiresRoot = false,
            isInstalled = true,
            isEnabled = true,
            impactRating = "High",
            appliedConfigSummary = "vsync.pacing = strict; buffer_count = 2"
        ),

        // Background Process Management
        OptimizationModule(
            id = "mod_bg_freeze",
            name = "Aggressive Background App Freezer",
            category = ModuleCategory.BACKGROUND_PROCESSES,
            summary = "Freezes social, messaging, and shop apps while MLBB is foreground active.",
            details = "Uses standard Android killBackgroundProcesses and Shizuku cmd appops to prevent background CPU interrupts.",
            safeForPotato = true,
            requiresShizuku = true,
            requiresRoot = false,
            isInstalled = true,
            isEnabled = true,
            impactRating = "Extreme",
            appliedConfigSummary = "cmd activity kill-all; killBackgroundProcesses"
        ),
        OptimizationModule(
            id = "mod_doze_game",
            name = "Gaming Doze Mode Assistant",
            category = ModuleCategory.BACKGROUND_PROCESSES,
            summary = "Suppresses non-priority wake locks and background cloud synchronizations.",
            details = "Prevents system Google Play auto-updates or photo uploads from starting mid-game.",
            safeForPotato = true,
            requiresShizuku = true,
            requiresRoot = false,
            isInstalled = true,
            isEnabled = false,
            impactRating = "Medium",
            appliedConfigSummary = "cmd deviceidle step"
        )
    )

    private val _modules = MutableStateFlow(defaultModules)
    val modules: StateFlow<List<OptimizationModule>> = _modules.asStateFlow()

    private val _backupStatus = MutableStateFlow("Default Configuration")
    val backupStatus: StateFlow<String> = _backupStatus.asStateFlow()

    fun toggleModule(id: String) {
        _modules.value = _modules.value.map { mod ->
            if (mod.id == id) {
                mod.copy(isEnabled = !mod.isEnabled)
            } else mod
        }
    }

    fun installModule(id: String) {
        _modules.value = _modules.value.map { mod ->
            if (mod.id == id) {
                mod.copy(isInstalled = true, isEnabled = true)
            } else mod
        }
    }

    fun uninstallModule(id: String) {
        _modules.value = _modules.value.map { mod ->
            if (mod.id == id) {
                mod.copy(isInstalled = false, isEnabled = false)
            } else mod
        }
    }

    fun createBackup(): String {
        val activeCount = _modules.value.count { it.isEnabled }
        val backupName = "Backup_${System.currentTimeMillis() % 100000} ($activeCount active modules)"
        _backupStatus.value = backupName
        return backupName
    }

    fun restoreDefaults() {
        _modules.value = defaultModules
        _backupStatus.value = "Default Configuration"
    }
}
