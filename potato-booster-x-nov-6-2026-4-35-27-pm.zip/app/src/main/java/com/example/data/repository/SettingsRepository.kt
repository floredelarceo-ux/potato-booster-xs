package com.example.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.example.data.model.ProfileType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    val autoBoostOnLaunch: Boolean = true,
    val autoRestoreOnExit: Boolean = true,
    val keepScreenAwake: Boolean = true,
    val gamingModeDndReminder: Boolean = true,
    val batteryTempWarningThreshold: Int = 42,
    val selectedProfile: ProfileType = ProfileType.POTATO,
    val selectedRefreshRate: Float = 60f,
    val selectedMapThemeId: String = "map_western_contrast",
    val mapBrightness: Float = 1.05f,
    val mapContrast: Float = 1.25f
)

class SettingsRepository(private val context: Context) {

    private val _settings = MutableStateFlow(AppSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    fun updateAutoBoost(enabled: Boolean) {
        _settings.value = _settings.value.copy(autoBoostOnLaunch = enabled)
    }

    fun updateAutoRestore(enabled: Boolean) {
        _settings.value = _settings.value.copy(autoRestoreOnExit = enabled)
    }

    fun updateKeepScreenAwake(enabled: Boolean) {
        _settings.value = _settings.value.copy(keepScreenAwake = enabled)
    }

    fun updateGamingDnd(enabled: Boolean) {
        _settings.value = _settings.value.copy(gamingModeDndReminder = enabled)
    }

    fun updateTempThreshold(threshold: Int) {
        _settings.value = _settings.value.copy(batteryTempWarningThreshold = threshold)
    }

    fun updateProfile(profile: ProfileType) {
        _settings.value = _settings.value.copy(selectedProfile = profile)
    }

    fun updateRefreshRate(rate: Float) {
        _settings.value = _settings.value.copy(selectedRefreshRate = rate)
    }

    fun updateMapTheme(themeId: String, brightness: Float, contrast: Float) {
        _settings.value = _settings.value.copy(
            selectedMapThemeId = themeId,
            mapBrightness = brightness,
            mapContrast = contrast
        )
    }

    fun resetToDefaults() {
        _settings.value = AppSettings()
    }
}
