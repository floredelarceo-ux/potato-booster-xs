package com.example.data.repository

import com.example.data.model.MLBBGraphicPreset
import com.example.data.model.MapThemePreset

class MLBBRepository {

    val graphicPresets = listOf(
        MLBBGraphicPreset(
            id = "preset_potato",
            title = "Potato Ultra-Smooth",
            targetDeviceTag = "Potato (2GB - 3GB RAM)",
            recommendedRam = "2GB - 3GB",
            targetFps = 60,
            inGameSettings = listOf(
                "Graphics Quality" to "Smooth",
                "High Frame Rate" to "ON (Crucial)",
                "Shadows" to "OFF",
                "Damage Text" to "ON",
                "Hero Outline" to "OFF",
                "Screen Shake" to "OFF",
                "HD Mode" to "OFF",
                "Creep HP Indicator" to "ON",
                "Skill Targeting" to "Standard (Low FX)"
            ),
            boosterActions = listOf(
                "Trims background app cache",
                "Pre-warms DNS for Moonton servers",
                "Pins MLBB process priority",
                "Enables aggressive LMK memory release"
            )
        ),
        MLBBGraphicPreset(
            id = "preset_low",
            title = "Low Balanced Speed",
            targetDeviceTag = "Entry Level (3GB - 4GB RAM)",
            recommendedRam = "3GB - 4GB",
            targetFps = 60,
            inGameSettings = listOf(
                "Graphics Quality" to "Low",
                "High Frame Rate" to "ON",
                "Shadows" to "OFF",
                "Damage Text" to "ON",
                "Hero Outline" to "OFF",
                "Screen Shake" to "OFF",
                "HD Mode" to "OFF",
                "Creep HP Indicator" to "ON",
                "Color Blind Filter" to "Standard"
            ),
            boosterActions = listOf(
                "Reclaims cached RAM",
                "Sets window animation scale to 0.5x",
                "Optimizes touch event latency"
            )
        ),
        MLBBGraphicPreset(
            id = "preset_balanced",
            title = "Balanced Competitive",
            targetDeviceTag = "Mid-Range (4GB - 6GB RAM)",
            recommendedRam = "4GB - 6GB",
            targetFps = 60,
            inGameSettings = listOf(
                "Graphics Quality" to "Medium",
                "High Frame Rate" to "High (60-90 FPS)",
                "Shadows" to "ON",
                "Damage Text" to "ON",
                "Hero Outline" to "ON",
                "Screen Shake" to "OFF",
                "HD Mode" to "ON",
                "Creep HP Indicator" to "ON",
                "Camera Height" to "High"
            ),
            boosterActions = listOf(
                "Balances thermal threshold",
                "Synchronizes frame pacing buffer",
                "Suppresses background notifications"
            )
        ),
        MLBBGraphicPreset(
            id = "preset_performance",
            title = "Max Refresh Overdrive",
            targetDeviceTag = "Gaming High-End (6GB+ RAM)",
            recommendedRam = "6GB - 12GB",
            targetFps = 120,
            inGameSettings = listOf(
                "Graphics Quality" to "High / Ultra",
                "High Frame Rate" to "Super / Ultra (120 FPS)",
                "Shadows" to "ON",
                "Damage Text" to "ON",
                "Hero Outline" to "ON",
                "Screen Shake" to "ON",
                "HD Mode" to "ON",
                "Creep HP Indicator" to "ON",
                "Water Reflection" to "Smooth"
            ),
            boosterActions = listOf(
                "Forces maximum display refresh rate",
                "Applies Shizuku dexopt speed compile",
                "Locks touch response to 240Hz polling"
            )
        )
    )

    val mapPresets = listOf(
        MapThemePreset(
            id = "map_western_contrast",
            title = "Western Expanse - High Contrast",
            mapName = "Western Expanse",
            description = "Deepens bush shadows and amplifies river boundary lines for easier gank spotting.",
            colorFilterHex = 0xFF00E5FF,
            contrastBoost = 1.25f,
            brightnessMultiplier = 1.05f,
            saturationMultiplier = 1.20f,
            potatoPerks = "Clarifies ambush bushes with zero GPU overhead."
        ),
        MapThemePreset(
            id = "map_sanctuary_soft",
            title = "Imperial Sanctuary - Anti-Lag Tones",
            mapName = "Imperial Sanctuary",
            description = "Subtle desaturated ambient palette that cuts visual glare and eye fatigue during long ranked grinds.",
            colorFilterHex = 0xFF818CF8,
            contrastBoost = 1.05f,
            brightnessMultiplier = 0.95f,
            saturationMultiplier = 0.85f,
            potatoPerks = "Mutes chaotic spell flashes for clearer hero tracking."
        ),
        MapThemePreset(
            id = "map_celestial_vibrant",
            title = "Celestial Palace - Skill Highlights",
            mapName = "Celestial Palace",
            description = "Elevates warm golden tones so skill skillshots, hero hitboxes, and Lord reticles pop out distinctly.",
            colorFilterHex = 0xFFFFB703,
            contrastBoost = 1.30f,
            brightnessMultiplier = 1.10f,
            saturationMultiplier = 1.35f,
            potatoPerks = "Improves Lord / Turtle smite visibility."
        ),
        MapThemePreset(
            id = "map_cyber_night",
            title = "Neon Cyber Grid - Potato Night Mode",
            mapName = "All Maps (Universal)",
            description = "Darkens static lane terrain to OLED near-black while keeping lane minions and heroes illuminated.",
            colorFilterHex = 0xFF00FF9D,
            contrastBoost = 1.40f,
            brightnessMultiplier = 0.90f,
            saturationMultiplier = 1.15f,
            potatoPerks = "Reduces screen power consumption by up to 22%."
        )
    )
}
