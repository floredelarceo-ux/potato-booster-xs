package com.example

import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.BoostDialog
import com.example.ui.components.StatusBadge
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MLBBPotatoScreen
import com.example.ui.screens.ModulesScreen
import com.example.ui.screens.PerformanceScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.ChakraPetchFontFamily
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.FieryOrange
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.PotatoBoosterTheme
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TextGrayMuted
import com.example.ui.theme.TextGraySecondary
import com.example.ui.theme.TextWhitePrimary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val viewModel: MainViewModel = viewModel()
            val settings by viewModel.settings.collectAsState()

            // Handle Keep Screen Awake
            LaunchedEffect(settings.keepScreenAwake) {
                try {
                    if (settings.keepScreenAwake) {
                        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    } else {
                        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                } catch (_: Throwable) {}
            }

            PotatoBoosterTheme {
                MainApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainApp(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val shizuku by viewModel.shizukuState.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    if (currentScreen == AppScreen.SPLASH) {
        SplashScreen(
            onContinue = { viewModel.navigateTo(AppScreen.HOME) }
        )
    } else {
        // Back press handling
        BackHandler(enabled = currentScreen != AppScreen.HOME) {
            viewModel.navigateTo(AppScreen.HOME)
        }

        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(CyberBackground),
            containerColor = CyberBackground,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                AppTopBar(
                    onLogoClick = { viewModel.navigateTo(AppScreen.HOME) },
                    shizukuConnected = shizuku.canExecuteElevated,
                    shizukuInstalled = shizuku.isInstalled
                )
            },
            bottomBar = {
                AppBottomNav(
                    currentScreen = currentScreen,
                    onNavigate = { viewModel.navigateTo(it) }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                AnimatedContent(
                    targetState = currentScreen,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "screen_transition"
                ) { screen ->
                    when (screen) {
                        AppScreen.SPLASH -> SplashScreen(onContinue = { viewModel.navigateTo(AppScreen.HOME) })
                        AppScreen.HOME -> HomeScreen(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
                        AppScreen.MLBB -> MLBBPotatoScreen(viewModel = viewModel)
                        AppScreen.PERFORMANCE -> PerformanceScreen(viewModel = viewModel)
                        AppScreen.MODULES -> ModulesScreen(viewModel = viewModel)
                        AppScreen.SETTINGS -> SettingsScreen(viewModel = viewModel)
                    }
                }

                // Global Boost Dialog
                BoostDialog(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun AppTopBar(
    onLogoClick: () -> Unit,
    shizukuConnected: Boolean,
    shizukuInstalled: Boolean
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding(),
        color = CyberSurface.copy(alpha = 0.95f),
        border = androidx.compose.foundation.BorderStroke(0.5.dp, CyberCardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.testTag("app_branding_header")
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_potato_booster_logo_1793951539937),
                    contentDescription = "App Icon",
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .border(1.dp, NeonCyan, CircleShape)
                )

                Column {
                    Text(
                        text = "POTATO BOOSTER X",
                        fontFamily = RajdhaniFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        letterSpacing = 1.sp,
                        color = TextWhitePrimary
                    )
                    Text(
                        text = "MAXIMUM PERFORMANCE. MINIMUM LAG.",
                        fontFamily = ChakraPetchFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 9.sp,
                        letterSpacing = 0.5.sp,
                        color = NeonCyan
                    )
                }
            }

            StatusBadge(
                text = if (shizukuConnected) "SHIZUKU" else if (shizukuInstalled) "SHIZUKU OFF" else "MODE A",
                accentColor = if (shizukuConnected) NeonGreen else FieryOrange,
                isPulsing = !shizukuConnected
            )
        }
    }
}

@Composable
fun AppBottomNav(
    currentScreen: AppScreen,
    onNavigate: (AppScreen) -> Unit
) {
    NavigationBar(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
        containerColor = CyberSurface,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = currentScreen == AppScreen.HOME,
            onClick = { onNavigate(AppScreen.HOME) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == AppScreen.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                    contentDescription = "Home"
                )
            },
            label = {
                Text(
                    text = "HOME",
                    fontFamily = RajdhaniFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberBackground,
                selectedTextColor = NeonCyan,
                indicatorColor = NeonCyan,
                unselectedIconColor = TextGrayMuted,
                unselectedTextColor = TextGrayMuted
            ),
            modifier = Modifier.testTag("nav_item_home")
        )

        NavigationBarItem(
            selected = currentScreen == AppScreen.MLBB,
            onClick = { onNavigate(AppScreen.MLBB) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == AppScreen.MLBB) Icons.Filled.SportsEsports else Icons.Outlined.SportsEsports,
                    contentDescription = "MLBB"
                )
            },
            label = {
                Text(
                    text = "MLBB",
                    fontFamily = RajdhaniFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberBackground,
                selectedTextColor = NeonCyan,
                indicatorColor = NeonCyan,
                unselectedIconColor = TextGrayMuted,
                unselectedTextColor = TextGrayMuted
            ),
            modifier = Modifier.testTag("nav_item_mlbb")
        )

        NavigationBarItem(
            selected = currentScreen == AppScreen.PERFORMANCE,
            onClick = { onNavigate(AppScreen.PERFORMANCE) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == AppScreen.PERFORMANCE) Icons.Filled.Speed else Icons.Outlined.Speed,
                    contentDescription = "Performance"
                )
            },
            label = {
                Text(
                    text = "FPS/HZ",
                    fontFamily = RajdhaniFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberBackground,
                selectedTextColor = NeonCyan,
                indicatorColor = NeonCyan,
                unselectedIconColor = TextGrayMuted,
                unselectedTextColor = TextGrayMuted
            ),
            modifier = Modifier.testTag("nav_item_performance")
        )

        NavigationBarItem(
            selected = currentScreen == AppScreen.MODULES,
            onClick = { onNavigate(AppScreen.MODULES) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == AppScreen.MODULES) Icons.Filled.Extension else Icons.Outlined.Extension,
                    contentDescription = "Modules"
                )
            },
            label = {
                Text(
                    text = "MODULES",
                    fontFamily = RajdhaniFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberBackground,
                selectedTextColor = NeonCyan,
                indicatorColor = NeonCyan,
                unselectedIconColor = TextGrayMuted,
                unselectedTextColor = TextGrayMuted
            ),
            modifier = Modifier.testTag("nav_item_modules")
        )

        NavigationBarItem(
            selected = currentScreen == AppScreen.SETTINGS,
            onClick = { onNavigate(AppScreen.SETTINGS) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == AppScreen.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                    contentDescription = "Settings"
                )
            },
            label = {
                Text(
                    text = "SETTINGS",
                    fontFamily = RajdhaniFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = CyberBackground,
                selectedTextColor = NeonCyan,
                indicatorColor = NeonCyan,
                unselectedIconColor = TextGrayMuted,
                unselectedTextColor = TextGrayMuted
            ),
            modifier = Modifier.testTag("nav_item_settings")
        )
    }
}
