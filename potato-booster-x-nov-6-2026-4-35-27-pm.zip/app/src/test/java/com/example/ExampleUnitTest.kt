package com.example

import com.example.data.model.ModuleCategory
import com.example.data.model.ProfileType
import com.example.data.repository.MLBBRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun `mlbb repository provides presets and map themes`() {
    val repo = MLBBRepository()
    assertTrue(repo.graphicPresets.isNotEmpty())
    assertTrue(repo.mapPresets.isNotEmpty())

    val potatoPreset = repo.graphicPresets.first { it.id == "preset_potato" }
    assertEquals(60, potatoPreset.targetFps)
    assertTrue(potatoPreset.inGameSettings.any { it.first == "Graphics Quality" && it.second == "Smooth" })
  }
}
